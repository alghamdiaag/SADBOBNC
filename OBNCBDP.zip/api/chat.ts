import { OpenAI } from 'openai';
import { getContextFromRAG } from '../src/lib/rag';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { messages } = req.body;
    const lastMessage = messages[messages.length - 1].content;
    
    // Get relevant context from RAG
    const context = await getContextFromRAG(lastMessage);
    
    const systemPrompt = {
      role: 'system',
      content: `You are OBNC's AI assistant for the Saudi OBNC Digital Business Platform. Use the following context to answer questions: ${JSON.stringify(context)}`
    };

    const completion = await openai.chat.completions.create({
      model: 'gpt-4-turbo-preview',
      messages: [systemPrompt, ...messages],
      temperature: 0.7,
      max_tokens: 500,
    });

    return res.status(200).json({ response: completion.choices[0].message.content });
  } catch (error) {
    console.error('Error in chat endpoint:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}