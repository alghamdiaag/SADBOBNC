import { useState, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { ServiceRequest, ServiceDocument } from '../types/service';
import { toast } from 'react-hot-toast';

export function useServiceExecution(serviceRequestId: string) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const uploadDocument = useCallback(async (file: File): Promise<ServiceDocument> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${serviceRequestId}/${Date.now()}.${fileExt}`;
      
      const { data, error: uploadError } = await supabase.storage
        .from('service-documents')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: document, error: docError } = await supabase
        .from('service_documents')
        .insert({
          service_request_id: serviceRequestId,
          name: file.name,
          type: file.type,
          url: data.path,
          uploaded_by: 'current_user', // Replace with actual user ID
          status: 'pending'
        })
        .select()
        .single();

      if (docError) throw docError;

      toast.success('Document uploaded successfully');
      return document;
    } catch (err) {
      toast.error('Failed to upload document');
      throw err;
    }
  }, [serviceRequestId]);

  const updateServiceStatus = useCallback(async (
    status: ServiceRequest['status'],
    currentStep?: number
  ) => {
    try {
      setLoading(true);
      const { error: updateError } = await supabase
        .from('service_requests')
        .update({
          status,
          ...(currentStep !== undefined && { 'timeline.currentStep': currentStep })
        })
        .eq('id', serviceRequestId);

      if (updateError) throw updateError;

      toast.success('Service status updated');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update status');
      toast.error('Failed to update service status');
    } finally {
      setLoading(false);
    }
  }, [serviceRequestId]);

  const sendMessage = useCallback(async (
    content: string,
    attachments?: File[]
  ) => {
    try {
      setLoading(true);
      
      // Upload attachments first if any
      const uploadedAttachments = attachments 
        ? await Promise.all(attachments.map(uploadDocument))
        : [];

      const { error: messageError } = await supabase
        .from('service_messages')
        .insert({
          service_request_id: serviceRequestId,
          sender_id: 'current_user', // Replace with actual user ID
          content,
          attachments: uploadedAttachments.map(a => a.id)
        });

      if (messageError) throw messageError;

      toast.success('Message sent');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to send message');
      toast.error('Failed to send message');
    } finally {
      setLoading(false);
    }
  }, [serviceRequestId, uploadDocument]);

  return {
    loading,
    error,
    uploadDocument,
    updateServiceStatus,
    sendMessage
  };
}