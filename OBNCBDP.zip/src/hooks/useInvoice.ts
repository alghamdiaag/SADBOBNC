import { useState, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { Invoice, InvoiceItem } from '../types/invoice';
import { toast } from 'react-hot-toast';

export function useInvoice(invoiceId?: string) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createInvoice = useCallback(async (
    serviceRequestId: string,
    customerId: string,
    providerId: string,
    items: InvoiceItem[],
    notes?: string
  ): Promise<Invoice> => {
    try {
      setLoading(true);

      const subtotal = items.reduce((sum, item) => sum + item.total, 0);
      const vat = subtotal * 0.15;
      const total = subtotal + vat;

      const { data: invoice, error: createError } = await supabase
        .from('invoices')
        .insert({
          service_request_id: serviceRequestId,
          customer_id: customerId,
          provider_id: providerId,
          status: 'draft',
          items,
          subtotal,
          vat,
          total,
          currency: 'SAR',
          due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          invoice_number: `INV-${Date.now()}`,
          notes
        })
        .select()
        .single();

      if (createError) throw createError;

      toast.success('Invoice created successfully');
      return invoice;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to create invoice';
      setError(message);
      toast.error(message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const updateInvoiceStatus = useCallback(async (
    id: string,
    status: Invoice['status'],
    paymentId?: string
  ) => {
    try {
      setLoading(true);

      const { error: updateError } = await supabase
        .from('invoices')
        .update({
          status,
          payment_id: paymentId,
          paid_at: status === 'paid' ? new Date().toISOString() : null
        })
        .eq('id', id);

      if (updateError) throw updateError;

      toast.success('Invoice status updated');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to update invoice';
      setError(message);
      toast.error(message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    loading,
    error,
    createInvoice,
    updateInvoiceStatus
  };
}