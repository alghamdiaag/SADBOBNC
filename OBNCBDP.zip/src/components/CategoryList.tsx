import React from 'react';
import { 
  Scale, Building2, Landmark, Construction, Briefcase, Users, 
  HardHat, Shield, Factory, Video, Hotel, CalendarCheck, Building,
  UserCheck, Truck
} from 'lucide-react';
import { categories } from '../data/mockData';
import type { ServiceCategory } from '../types';

const iconComponents = {
  Scale,
  Building2,
  Landmark,
  Construction,
  Briefcase,
  Users,
  HardHat,
  Shield,
  Factory,
  Video,
  Hotel,
  CalendarCheck,
  Building,
  UserCheck,
  Truck
};

interface CategoryListProps {
  onSelect: (category: ServiceCategory) => void;
  selectedId?: string;
}

export function CategoryList({ onSelect, selectedId }: CategoryListProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
      {categories.map((category) => {
        const IconComponent = iconComponents[category.icon as keyof typeof iconComponents];
        const isSelected = selectedId === category.id;
        
        return (
          <button
            key={category.id}
            onClick={() => onSelect(category)}
            className={`group relative p-4 rounded-xl transition-all duration-200 overflow-hidden
              ${isSelected 
                ? 'bg-obnc-green-600 text-white shadow-md' 
                : 'bg-white hover:bg-gray-50 text-gray-600 hover:text-gray-900 border border-gray-200'}`}
          >
            <div className="relative z-10 flex flex-col items-center text-center gap-2">
              <IconComponent className={`w-6 h-6 transition-colors duration-200 ${
                isSelected ? 'text-white' : 'text-gray-400 group-hover:text-obnc-green-500'
              }`} />
              <h3 className="font-medium text-sm">{category.name}</h3>
              <p className={`text-xs line-clamp-2 ${
                isSelected ? 'text-obnc-green-100' : 'text-gray-500'
              }`}>
                {category.description}
              </p>
            </div>
            {isSelected && (
              <div className="absolute inset-0 bg-obnc-green-600 opacity-10 transform scale-[2] rotate-45"></div>
            )}
          </button>
        );
      })}
    </div>
  );
}