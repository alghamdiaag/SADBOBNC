import React, { useState } from 'react';
import { Building2, Target, Clock, Briefcase, MapPin } from 'lucide-react';

interface UserContext {
  businessStage: 'planning' | 'startup' | 'established' | 'expanding';
  primaryGoal: 'market_entry' | 'licensing' | 'expansion' | 'investment' | 'operations';
  timeline: 'immediate' | '3_months' | '6_months' | 'flexible';
  industryType: string;
  location: 'local' | 'international';
}

interface UserContextFormProps {
  onSubmit: (data: UserContext) => void;
}

export function UserContextForm({ onSubmit }: UserContextFormProps) {
  const [formData, setFormData] = useState<UserContext>({
    businessStage: 'planning',
    primaryGoal: 'market_entry',
    timeline: 'immediate',
    industryType: '',
    location: 'local'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-sm p-8">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900">Help Us Serve You Better</h2>
        <p className="mt-2 text-gray-600">
          Answer these quick questions so we can personalize your experience
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Business Stage */}
        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-3">
            <Building2 className="w-5 h-5 text-obnc-green-600" />
            What stage is your business in?
          </label>
          <div className="grid grid-cols-2 gap-3">
            {[
              { value: 'planning', label: 'Planning Phase' },
              { value: 'startup', label: 'Startup' },
              { value: 'established', label: 'Established' },
              { value: 'expanding', label: 'Expanding' }
            ].map((option) => (
              <button
                key={option.value}
                type="button"
                onClick={() => setFormData({ ...formData, businessStage: option.value as any })}
                className={`p-3 text-sm font-medium rounded-lg transition-colors
                  ${formData.businessStage === option.value
                    ? 'bg-obnc-green-600 text-white'
                    : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                  }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>

        {/* Primary Goal */}
        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-3">
            <Target className="w-5 h-5 text-obnc-green-600" />
            What's your primary goal?
          </label>
          <select
            value={formData.primaryGoal}
            onChange={(e) => setFormData({ ...formData, primaryGoal: e.target.value as any })}
            className="w-full p-3 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
          >
            <option value="market_entry">Enter Saudi Market</option>
            <option value="licensing">Obtain Licenses & Permits</option>
            <option value="expansion">Business Expansion</option>
            <option value="investment">Seek Investment</option>
            <option value="operations">Improve Operations</option>
          </select>
        </div>

        {/* Timeline */}
        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-3">
            <Clock className="w-5 h-5 text-obnc-green-600" />
            What's your preferred timeline?
          </label>
          <div className="grid grid-cols-2 gap-3">
            {[
              { value: 'immediate', label: 'Immediate' },
              { value: '3_months', label: 'Within 3 Months' },
              { value: '6_months', label: 'Within 6 Months' },
              { value: 'flexible', label: 'Flexible' }
            ].map((option) => (
              <button
                key={option.value}
                type="button"
                onClick={() => setFormData({ ...formData, timeline: option.value as any })}
                className={`p-3 text-sm font-medium rounded-lg transition-colors
                  ${formData.timeline === option.value
                    ? 'bg-obnc-green-600 text-white'
                    : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                  }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>

        {/* Industry Type */}
        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-3">
            <Briefcase className="w-5 h-5 text-obnc-green-600" />
            What industry are you in?
          </label>
          <input
            type="text"
            value={formData.industryType}
            onChange={(e) => setFormData({ ...formData, industryType: e.target.value })}
            placeholder="e.g., Technology, Manufacturing, Retail"
            className="w-full p-3 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
          />
        </div>

        {/* Location */}
        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-3">
            <MapPin className="w-5 h-5 text-obnc-green-600" />
            Where are you based?
          </label>
          <div className="grid grid-cols-2 gap-3">
            {[
              { value: 'local', label: 'Within Saudi Arabia' },
              { value: 'international', label: 'International' }
            ].map((option) => (
              <button
                key={option.value}
                type="button"
                onClick={() => setFormData({ ...formData, location: option.value as any })}
                className={`p-3 text-sm font-medium rounded-lg transition-colors
                  ${formData.location === option.value
                    ? 'bg-obnc-green-600 text-white'
                    : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                  }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>

        <button
          type="submit"
          className="w-full py-3 px-4 bg-obnc-green-600 text-white font-medium rounded-lg hover:bg-obnc-green-700 transition-colors"
        >
          Continue
        </button>
      </form>
    </div>
  );
}