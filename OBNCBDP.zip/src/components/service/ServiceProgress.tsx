import React from 'react';
import { CheckCircle2, Clock, AlertCircle, ArrowRight } from 'lucide-react';
import type { ServiceTimeline } from '../../types/service';

interface ServiceProgressProps {
  timeline: ServiceTimeline;
}

export function ServiceProgress({ timeline }: ServiceProgressProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">Service Progress</h3>
      <div className="space-y-4">
        {timeline.steps.map((step, index) => {
          const isCurrent = index === timeline.currentStep;
          const isCompleted = step.status === 'completed';
          const isBlocked = step.status === 'blocked';

          return (
            <div key={step.id} className="relative">
              {index !== timeline.steps.length - 1 && (
                <div className={`absolute left-4 top-10 w-0.5 h-full -z-10
                  ${isCompleted ? 'bg-obnc-green-500' : 'bg-gray-200'}`} 
                />
              )}
              
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 mt-1">
                  {isCompleted ? (
                    <CheckCircle2 className="w-8 h-8 text-obnc-green-500" />
                  ) : isCurrent ? (
                    <Clock className="w-8 h-8 text-blue-500" />
                  ) : isBlocked ? (
                    <AlertCircle className="w-8 h-8 text-obnc-red-500" />
                  ) : (
                    <div className="w-8 h-8 rounded-full border-2 border-gray-200" />
                  )}
                </div>
                
                <div className="flex-grow">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium text-gray-900">{step.title}</h4>
                    {step.completedAt && (
                      <span className="text-sm text-gray-500">
                        Completed on {new Date(step.completedAt).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                  
                  <p className="text-sm text-gray-600 mt-1">{step.description}</p>
                  
                  {step.requiredDocuments && step.requiredDocuments.length > 0 && (
                    <div className="mt-3">
                      <p className="text-sm font-medium text-gray-700">Required Documents:</p>
                      <ul className="mt-2 space-y-2">
                        {step.requiredDocuments.map((doc, idx) => (
                          <li key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                            <ArrowRight className="w-4 h-4" />
                            {doc}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {isCurrent && (
                    <div className="mt-4">
                      <button className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-obnc-green-600 rounded-lg hover:bg-obnc-green-700 transition-colors">
                        View Details
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}