import React from 'react';
import { Download, CreditCard } from 'lucide-react';
import type { Invoice } from '../../types/invoice';

interface InvoiceViewProps {
  invoice: Invoice;
  onPay?: () => void;
  onDownload?: () => void;
}

export function InvoiceView({ invoice, onPay, onDownload }: InvoiceViewProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Invoice</h2>
            <p className="text-sm text-gray-600 mt-1">#{invoice.invoiceNumber}</p>
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-600">Issue Date</div>
            <div className="font-medium">
              {new Date(invoice.createdAt).toLocaleDateString()}
            </div>
            <div className="text-sm text-gray-600 mt-2">Due Date</div>
            <div className="font-medium">
              {new Date(invoice.dueDate).toLocaleDateString()}
            </div>
          </div>
        </div>
      </div>

      {/* Items */}
      <div className="p-6">
        <table className="w-full">
          <thead>
            <tr className="text-left text-sm text-gray-600">
              <th className="pb-4">Description</th>
              <th className="pb-4 text-right">Qty</th>
              <th className="pb-4 text-right">Unit Price</th>
              <th className="pb-4 text-right">Total</th>
            </tr>
          </thead>
          <tbody className="border-t border-gray-200">
            {invoice.items.map((item) => (
              <tr key={item.id} className="border-b border-gray-200">
                <td className="py-4">
                  <div className="font-medium text-gray-900">{item.description}</div>
                  {item.serviceDetails && (
                    <div className="text-sm text-gray-600 mt-1">{item.serviceDetails}</div>
                  )}
                </td>
                <td className="py-4 text-right">{item.quantity}</td>
                <td className="py-4 text-right">
                  {invoice.currency} {item.unitPrice.toFixed(2)}
                </td>
                <td className="py-4 text-right">
                  {invoice.currency} {item.total.toFixed(2)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="mt-6 border-t border-gray-200 pt-6">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Subtotal</span>
              <span className="font-medium">
                {invoice.currency} {invoice.subtotal.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">VAT (15%)</span>
              <span className="font-medium">
                {invoice.currency} {invoice.vat.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between text-lg font-bold border-t border-gray-200 pt-2">
              <span>Total</span>
              <span>{invoice.currency} {invoice.total.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {invoice.notes && (
          <div className="mt-6 text-sm text-gray-600">
            <h4 className="font-medium text-gray-900">Notes</h4>
            <p className="mt-1">{invoice.notes}</p>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="p-6 bg-gray-50 rounded-b-xl border-t border-gray-200">
        <div className="flex justify-between items-center">
          <div>
            <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium
              ${invoice.status === 'paid'
                ? 'bg-green-100 text-green-800'
                : invoice.status === 'issued'
                ? 'bg-yellow-100 text-yellow-800'
                : 'bg-gray-100 text-gray-800'
              }`}
            >
              {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
            </span>
          </div>
          <div className="flex gap-3">
            {onDownload && (
              <button
                onClick={onDownload}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <Download className="w-4 h-4" />
                Download PDF
              </button>
            )}
            {onPay && invoice.status === 'issued' && (
              <button
                onClick={onPay}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-obnc-green-600 rounded-lg hover:bg-obnc-green-700 transition-colors"
              >
                <CreditCard className="w-4 h-4" />
                Pay Now
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}