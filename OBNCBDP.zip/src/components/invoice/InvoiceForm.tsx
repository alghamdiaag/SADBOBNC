import React, { useState } from 'react';
import { Plus, Minus, Calculator } from 'lucide-react';
import type { InvoiceItem } from '../../types/invoice';

interface InvoiceFormProps {
  onSubmit: (items: InvoiceItem[], notes?: string) => void;
  initialItems?: InvoiceItem[];
}

export function InvoiceForm({ onSubmit, initialItems = [] }: InvoiceFormProps) {
  const [items, setItems] = useState<InvoiceItem[]>(initialItems);
  const [notes, setNotes] = useState('');

  const addItem = () => {
    setItems([
      ...items,
      {
        id: crypto.randomUUID(),
        description: '',
        quantity: 1,
        unitPrice: 0,
        total: 0,
      },
    ]);
  };

  const removeItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const updateItem = (id: string, updates: Partial<InvoiceItem>) => {
    setItems(items.map(item => {
      if (item.id === id) {
        const updated = { ...item, ...updates };
        updated.total = updated.quantity * updated.unitPrice;
        return updated;
      }
      return item;
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(items, notes);
  };

  const subtotal = items.reduce((sum, item) => sum + item.total, 0);
  const vat = subtotal * 0.15; // 15% VAT
  const total = subtotal + vat;

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        {items.map((item) => (
          <div key={item.id} className="grid grid-cols-12 gap-4 items-start">
            <div className="col-span-4">
              <input
                type="text"
                value={item.description}
                onChange={(e) => updateItem(item.id, { description: e.target.value })}
                placeholder="Item description"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
                required
              />
            </div>
            <div className="col-span-2">
              <input
                type="number"
                value={item.quantity}
                onChange={(e) => updateItem(item.id, { quantity: Number(e.target.value) })}
                min="1"
                placeholder="Qty"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
                required
              />
            </div>
            <div className="col-span-2">
              <input
                type="number"
                value={item.unitPrice}
                onChange={(e) => updateItem(item.id, { unitPrice: Number(e.target.value) })}
                min="0"
                step="0.01"
                placeholder="Price"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
                required
              />
            </div>
            <div className="col-span-3">
              <input
                type="text"
                value={item.total.toFixed(2)}
                readOnly
                className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg"
              />
            </div>
            <div className="col-span-1">
              <button
                type="button"
                onClick={() => removeItem(item.id)}
                className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
              >
                <Minus className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <button
        type="button"
        onClick={addItem}
        className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-obnc-green-600 bg-obnc-green-50 rounded-lg hover:bg-obnc-green-100 transition-colors"
      >
        <Plus className="w-4 h-4" />
        Add Item
      </button>

      <div className="border-t border-gray-200 pt-4">
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Additional notes..."
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
          rows={3}
        />
      </div>

      <div className="bg-gray-50 p-4 rounded-lg space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Subtotal</span>
          <span className="font-medium">SAR {subtotal.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">VAT (15%)</span>
          <span className="font-medium">SAR {vat.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-base font-semibold border-t border-gray-200 pt-2">
          <span>Total</span>
          <span>SAR {total.toFixed(2)}</span>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          type="submit"
          className="flex items-center gap-2 px-6 py-2 bg-obnc-green-600 text-white font-medium rounded-lg hover:bg-obnc-green-700 transition-colors"
        >
          <Calculator className="w-4 h-4" />
          Generate Invoice
        </button>
      </div>
    </form>
  );
}