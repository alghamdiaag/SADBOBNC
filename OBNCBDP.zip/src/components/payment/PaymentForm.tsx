import React, { useState } from 'react';
import { CreditCard, Calendar, Lock } from 'lucide-react';
import { createPaymentIntent } from '../../lib/moyasar';
import type { Invoice } from '../../types/invoice';

interface PaymentFormProps {
  invoice: Invoice;
  onSuccess: (paymentId: string) => void;
  onError: (error: Error) => void;
}

export function PaymentForm({ invoice, onSuccess, onError }: PaymentFormProps) {
  const [loading, setLoading] = useState(false);
  const [cardDetails, setCardDetails] = useState({
    name: '',
    number: '',
    expMonth: '',
    expYear: '',
    cvc: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payment = await createPaymentIntent(
        invoice.total,
        invoice.currency,
        `Payment for invoice #${invoice.invoiceNumber}`,
        {
          invoice_id: invoice.id,
          customer_id: invoice.customerId,
          customer_name: cardDetails.name,
          card_number: cardDetails.number.replace(/\s/g, ''),
          exp_month: cardDetails.expMonth,
          exp_year: cardDetails.expYear,
          cvc: cardDetails.cvc
        }
      );

      onSuccess(payment.id);
    } catch (err) {
      onError(err instanceof Error ? err : new Error('Payment failed'));
    } finally {
      setLoading(false);
    }
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length) {
      return parts.join(' ');
    } else {
      return value;
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Cardholder Name
          </label>
          <input
            type="text"
            value={cardDetails.name}
            onChange={(e) => setCardDetails({ ...cardDetails, name: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
            placeholder="Name on card"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Card Number
          </label>
          <div className="relative">
            <input
              type="text"
              value={cardDetails.number}
              onChange={(e) => setCardDetails({ 
                ...cardDetails, 
                number: formatCardNumber(e.target.value)
              })}
              className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
              placeholder="1234 5678 9012 3456"
              maxLength={19}
              required
            />
            <CreditCard className="absolute right-3 top-2.5 w-5 h-5 text-gray-400" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Expiry Date
            </label>
            <div className="relative">
              <input
                type="text"
                value={`${cardDetails.expMonth}/${cardDetails.expYear}`}
                onChange={(e) => {
                  const [month = '', year = ''] = e.target.value.split('/');
                  setCardDetails({
                    ...cardDetails,
                    expMonth: month.slice(0, 2),
                    expYear: year.slice(0, 2)
                  });
                }}
                className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
                placeholder="MM/YY"
                maxLength={5}
                required
              />
              <Calendar className="absolute right-3 top-2.5 w-5 h-5 text-gray-400" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              CVC
            </label>
            <div className="relative">
              <input
                type="text"
                value={cardDetails.cvc}
                onChange={(e) => setCardDetails({
                  ...cardDetails,
                  cvc: e.target.value.replace(/\D/g, '').slice(0, 4)
                })}
                className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
                placeholder="123"
                maxLength={4}
                required
              />
              <Lock className="absolute right-3 top-2.5 w-5 h-5 text-gray-400" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-50 p-4 rounded-lg">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-gray-600">Amount to Pay</span>
          <span className="font-semibold text-lg">
            {invoice.currency} {invoice.total.toFixed(2)}
          </span>
        </div>
        <p className="text-xs text-gray-500">
          Your payment is secured by Moyasar Payment Gateway
        </p>
      </div>

      <button
        type="submit"
        disabled={loading}
        className={`w-full py-3 px-4 text-white font-medium rounded-lg
          ${loading
            ? 'bg-gray-400 cursor-not-allowed'
            : 'bg-obnc-green-600 hover:bg-obnc-green-700'
          } transition-colors`}
      >
        {loading ? 'Processing...' : 'Pay Now'}
      </button>
    </form>
  );
}