import React, { useState, useEffect } from 'react';
import { Building2, Target, Clock, Briefcase, MapPin, Phone, Mail, User } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { toast } from 'react-hot-toast';

interface UserProfile {
  id: string;
  email: string;
  phone: string;
  full_name: string;
  business_stage: 'planning' | 'startup' | 'established' | 'expanding';
  primary_goal: 'market_entry' | 'licensing' | 'expansion' | 'investment' | 'operations';
  timeline: 'immediate' | '3_months' | '6_months' | 'flexible';
  industry_type: string;
  location: 'local' | 'international';
  updated_at: string;
}

export function UserProfileSettings() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);

  useEffect(() => {
    if (user) {
      fetchProfile();
    }
  }, [user]);

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user?.id)
        .single();

      if (error) throw error;
      setProfile(data);
    } catch (error) {
      toast.error('Failed to load profile');
      console.error('Error loading profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile || !user) return;

    setSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: profile.full_name,
          phone: profile.phone,
          business_stage: profile.business_stage,
          primary_goal: profile.primary_goal,
          timeline: profile.timeline,
          industry_type: profile.industry_type,
          location: profile.location,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id);

      if (error) throw error;
      toast.success('Profile updated successfully');
    } catch (error) {
      toast.error('Failed to update profile');
      console.error('Error updating profile:', error);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading...</div>;
  }

  if (!profile) {
    return <div className="text-center py-8">Profile not found</div>;
  }

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-sm p-8">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900">Profile Settings</h2>
        <p className="mt-2 text-gray-600">
          Manage your profile information and preferences
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Basic Information */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-900">Basic Information</h3>
          
          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
              <User className="w-5 h-5 text-obnc-green-600" />
              Full Name
            </label>
            <input
              type="text"
              value={profile.full_name}
              onChange={(e) => setProfile({ ...profile, full_name: e.target.value })}
              className="w-full p-3 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
            />
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
              <Mail className="w-5 h-5 text-obnc-green-600" />
              Email
            </label>
            <input
              type="email"
              value={profile.email}
              disabled
              className="w-full p-3 text-sm border border-gray-200 bg-gray-50 rounded-lg text-gray-500"
            />
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
              <Phone className="w-5 h-5 text-obnc-green-600" />
              Phone Number
            </label>
            <input
              type="tel"
              value={profile.phone}
              onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
              className="w-full p-3 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
            />
          </div>
        </div>

        {/* Business Information */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-900">Business Information</h3>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
              <Building2 className="w-5 h-5 text-obnc-green-600" />
              Business Stage
            </label>
            <select
              value={profile.business_stage}
              onChange={(e) => setProfile({ ...profile, business_stage: e.target.value as any })}
              className="w-full p-3 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
            >
              <option value="planning">Planning Phase</option>
              <option value="startup">Startup</option>
              <option value="established">Established</option>
              <option value="expanding">Expanding</option>
            </select>
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
              <Target className="w-5 h-5 text-obnc-green-600" />
              Primary Goal
            </label>
            <select
              value={profile.primary_goal}
              onChange={(e) => setProfile({ ...profile, primary_goal: e.target.value as any })}
              className="w-full p-3 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
            >
              <option value="market_entry">Enter Saudi Market</option>
              <option value="licensing">Obtain Licenses & Permits</option>
              <option value="expansion">Business Expansion</option>
              <option value="investment">Seek Investment</option>
              <option value="operations">Improve Operations</option>
            </select>
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
              <Clock className="w-5 h-5 text-obnc-green-600" />
              Timeline
            </label>
            <select
              value={profile.timeline}
              onChange={(e) => setProfile({ ...profile, timeline: e.target.value as any })}
              className="w-full p-3 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
            >
              <option value="immediate">Immediate</option>
              <option value="3_months">Within 3 Months</option>
              <option value="6_months">Within 6 Months</option>
              <option value="flexible">Flexible</option>
            </select>
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
              <Briefcase className="w-5 h-5 text-obnc-green-600" />
              Industry Type
            </label>
            <input
              type="text"
              value={profile.industry_type}
              onChange={(e) => setProfile({ ...profile, industry_type: e.target.value })}
              className="w-full p-3 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
              placeholder="e.g., Technology, Manufacturing, Retail"
            />
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
              <MapPin className="w-5 h-5 text-obnc-green-600" />
              Location
            </label>
            <select
              value={profile.location}
              onChange={(e) => setProfile({ ...profile, location: e.target.value as any })}
              className="w-full p-3 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
            >
              <option value="local">Within Saudi Arabia</option>
              <option value="international">International</option>
            </select>
          </div>
        </div>

        <div className="pt-6 border-t border-gray-200">
          <button
            type="submit"
            disabled={saving}
            className={`w-full py-3 px-4 text-white font-medium rounded-lg
              ${saving
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-obnc-green-600 hover:bg-obnc-green-700'
              } transition-colors`}
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </form>
    </div>
  );
}