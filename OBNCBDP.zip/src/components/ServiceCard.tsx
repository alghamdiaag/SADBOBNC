import React from 'react';
import { Star, Clock, ChevronRight } from 'lucide-react';
import type { ServiceProvider } from '../types';

interface ServiceCardProps {
  provider: ServiceProvider;
  onClick: (provider: ServiceProvider) => void;
}

export function ServiceCard({ provider, onClick }: ServiceCardProps) {
  return (
    <div 
      onClick={() => onClick(provider)}
      className="group bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer overflow-hidden border border-gray-100 hover:border-obnc-green-100 transform hover:-translate-y-1"
    >
      <div className="aspect-video w-full overflow-hidden relative">
        <img 
          src={provider.image} 
          alt={provider.name}
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-200"
        />
        <div className="absolute top-3 right-3">
          <div className="flex items-center gap-1 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full">
            <Star className="w-4 h-4 text-obnc-red-500 fill-current" />
            <span className="text-sm font-medium">{provider.rating}</span>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-semibold text-lg text-gray-900 group-hover:text-obnc-green-600 transition-colors duration-200">
            {provider.name}
          </h3>
          <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-obnc-green-500 transform group-hover:translate-x-1 transition-all duration-200" />
        </div>
        
        <p className="text-sm text-gray-600 mb-4 line-clamp-2">{provider.description}</p>
        
        <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{provider.estimatedTimeline}</span>
          </div>
          <span>•</span>
          <span>{provider.reviewCount} reviews</span>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <div>
            <p className="text-xs text-gray-500">Starting from</p>
            <p className="font-semibold text-gray-900">
              {provider.pricing.currency} {provider.pricing.startingFrom.toLocaleString()}
            </p>
          </div>
          <button className="px-4 py-2 text-sm font-medium text-obnc-green-600 bg-obnc-green-50 rounded-lg hover:bg-obnc-green-100 transition-colors duration-200">
            View Details
          </button>
        </div>
      </div>
    </div>
  );
}