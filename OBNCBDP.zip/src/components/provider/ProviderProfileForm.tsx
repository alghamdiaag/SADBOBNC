import React, { useState } from 'react';
import { Building2, Users, Target, Briefcase, MapPin, Scale } from 'lucide-react';

interface ProviderProfile {
  specialties: string[];
  targetIndustries: string[];
  businessSizePreference: ('micro' | 'small' | 'medium' | 'large')[];
  clientStagePreference: ('planning' | 'startup' | 'established' | 'expanding')[];
  serviceRegions: string[];
  minimumProjectSize: number;
  maximumProjectSize: number;
  typicalTimeframe: string;
  languages: string[];
  certifications: string[];
}

interface ProviderProfileFormProps {
  onSubmit: (data: ProviderProfile) => Promise<void>;
  initialData?: Partial<ProviderProfile>;
}

export function ProviderProfileForm({ onSubmit, initialData }: ProviderProfileFormProps) {
  const [profile, setProfile] = useState<ProviderProfile>({
    specialties: initialData?.specialties || [],
    targetIndustries: initialData?.targetIndustries || [],
    businessSizePreference: initialData?.businessSizePreference || [],
    clientStagePreference: initialData?.clientStagePreference || [],
    serviceRegions: initialData?.serviceRegions || [],
    minimumProjectSize: initialData?.minimumProjectSize || 0,
    maximumProjectSize: initialData?.maximumProjectSize || 0,
    typicalTimeframe: initialData?.typicalTimeframe || '',
    languages: initialData?.languages || ['English', 'Arabic'],
    certifications: initialData?.certifications || []
  });

  const [newSpecialty, setNewSpecialty] = useState('');
  const [newIndustry, setNewIndustry] = useState('');
  const [newRegion, setNewRegion] = useState('');
  const [newCertification, setNewCertification] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSubmit(profile);
  };

  const addItem = (field: keyof ProviderProfile, value: string) => {
    if (value && Array.isArray(profile[field])) {
      setProfile({
        ...profile,
        [field]: [...(profile[field] as string[]), value]
      });
    }
  };

  const removeItem = (field: keyof ProviderProfile, index: number) => {
    if (Array.isArray(profile[field])) {
      setProfile({
        ...profile,
        [field]: (profile[field] as string[]).filter((_, i) => i !== index)
      });
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-sm p-8">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900">Service Provider Profile</h2>
        <p className="mt-2 text-gray-600">
          Help us match you with the right clients by providing detailed information about your services
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Specialties */}
        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
            <Briefcase className="w-5 h-5 text-obnc-green-600" />
            Service Specialties
          </label>
          <div className="flex gap-2 mb-2">
            <input
              type="text"
              value={newSpecialty}
              onChange={(e) => setNewSpecialty(e.target.value)}
              className="flex-grow p-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
              placeholder="Add a specialty..."
            />
            <button
              type="button"
              onClick={() => {
                addItem('specialties', newSpecialty);
                setNewSpecialty('');
              }}
              className="px-4 py-2 bg-obnc-green-600 text-white rounded-lg hover:bg-obnc-green-700"
            >
              Add
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {profile.specialties.map((specialty, index) => (
              <span
                key={index}
                className="inline-flex items-center gap-1 px-3 py-1 bg-obnc-green-50 text-obnc-green-700 rounded-full text-sm"
              >
                {specialty}
                <button
                  type="button"
                  onClick={() => removeItem('specialties', index)}
                  className="hover:text-red-500"
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        </div>

        {/* Target Industries */}
        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
            <Building2 className="w-5 h-5 text-obnc-green-600" />
            Target Industries
          </label>
          <div className="flex gap-2 mb-2">
            <input
              type="text"
              value={newIndustry}
              onChange={(e) => setNewIndustry(e.target.value)}
              className="flex-grow p-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
              placeholder="Add an industry..."
            />
            <button
              type="button"
              onClick={() => {
                addItem('targetIndustries', newIndustry);
                setNewIndustry('');
              }}
              className="px-4 py-2 bg-obnc-green-600 text-white rounded-lg hover:bg-obnc-green-700"
            >
              Add
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {profile.targetIndustries.map((industry, index) => (
              <span
                key={index}
                className="inline-flex items-center gap-1 px-3 py-1 bg-obnc-green-50 text-obnc-green-700 rounded-full text-sm"
              >
                {industry}
                <button
                  type="button"
                  onClick={() => removeItem('targetIndustries', index)}
                  className="hover:text-red-500"
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        </div>

        {/* Business Size Preference */}
        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
            <Users className="w-5 h-5 text-obnc-green-600" />
            Preferred Business Size
          </label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { value: 'micro', label: 'Micro (1-5 employees)' },
              { value: 'small', label: 'Small (6-50 employees)' },
              { value: 'medium', label: 'Medium (51-250 employees)' },
              { value: 'large', label: 'Large (250+ employees)' }
            ].map((size) => (
              <label
                key={size.value}
                className="flex items-center gap-2 p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50"
              >
                <input
                  type="checkbox"
                  checked={profile.businessSizePreference.includes(size.value as any)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setProfile({
                        ...profile,
                        businessSizePreference: [...profile.businessSizePreference, size.value as any]
                      });
                    } else {
                      setProfile({
                        ...profile,
                        businessSizePreference: profile.businessSizePreference.filter(s => s !== size.value)
                      });
                    }
                  }}
                  className="h-4 w-4 text-obnc-green-600 focus:ring-obnc-green-500"
                />
                <span className="text-sm text-gray-700">{size.label}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Client Stage Preference */}
        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
            <Target className="w-5 h-5 text-obnc-green-600" />
            Preferred Client Stage
          </label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { value: 'planning', label: 'Planning Phase' },
              { value: 'startup', label: 'Startup' },
              { value: 'established', label: 'Established' },
              { value: 'expanding', label: 'Expanding' }
            ].map((stage) => (
              <label
                key={stage.value}
                className="flex items-center gap-2 p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50"
              >
                <input
                  type="checkbox"
                  checked={profile.clientStagePreference.includes(stage.value as any)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setProfile({
                        ...profile,
                        clientStagePreference: [...profile.clientStagePreference, stage.value as any]
                      });
                    } else {
                      setProfile({
                        ...profile,
                        clientStagePreference: profile.clientStagePreference.filter(s => s !== stage.value)
                      });
                    }
                  }}
                  className="h-4 w-4 text-obnc-green-600 focus:ring-obnc-green-500"
                />
                <span className="text-sm text-gray-700">{stage.label}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Service Regions */}
        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
            <MapPin className="w-5 h-5 text-obnc-green-600" />
            Service Regions
          </label>
          <div className="flex gap-2 mb-2">
            <input
              type="text"
              value={newRegion}
              onChange={(e) => setNewRegion(e.target.value)}
              className="flex-grow p-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
              placeholder="Add a region..."
            />
            <button
              type="button"
              onClick={() => {
                addItem('serviceRegions', newRegion);
                setNewRegion('');
              }}
              className="px-4 py-2 bg-obnc-green-600 text-white rounded-lg hover:bg-obnc-green-700"
            >
              Add
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {profile.serviceRegions.map((region, index) => (
              <span
                key={index}
                className="inline-flex items-center gap-1 px-3 py-1 bg-obnc-green-50 text-obnc-green-700 rounded-full text-sm"
              >
                {region}
                <button
                  type="button"
                  onClick={() => removeItem('serviceRegions', index)}
                  className="hover:text-red-500"
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        </div>

        {/* Project Size Range */}
        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
            <Scale className="w-5 h-5 text-obnc-green-600" />
            Project Size Range (SAR)
          </label>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-gray-600">Minimum</label>
              <input
                type="number"
                value={profile.minimumProjectSize}
                onChange={(e) => setProfile({
                  ...profile,
                  minimumProjectSize: Number(e.target.value)
                })}
                className="w-full p-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
                min="0"
                step="1000"
              />
            </div>
            <div>
              <label className="text-sm text-gray-600">Maximum</label>
              <input
                type="number"
                value={profile.maximumProjectSize}
                onChange={(e) => setProfile({
                  ...profile,
                  maximumProjectSize: Number(e.target.value)
                })}
                className="w-full p-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
                min="0"
                step="1000"
              />
            </div>
          </div>
        </div>

        {/* Typical Timeframe */}
        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
            Typical Service Timeframe
          </label>
          <input
            type="text"
            value={profile.typicalTimeframe}
            onChange={(e) => setProfile({
              ...profile,
              typicalTimeframe: e.target.value
            })}
            className="w-full p-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
            placeholder="e.g., 2-3 weeks, 1-2 months"
          />
        </div>

        {/* Certifications */}
        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-900 mb-2">
            Professional Certifications
          </label>
          <div className="flex gap-2 mb-2">
            <input
              type="text"
              value={newCertification}
              onChange={(e) => setNewCertification(e.target.value)}
              className="flex-grow p-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
              placeholder="Add a certification..."
            />
            <button
              type="button"
              onClick={() => {
                addItem('certifications', newCertification);
                setNewCertification('');
              }}
              className="px-4 py-2 bg-obnc-green-600 text-white rounded-lg hover:bg-obnc-green-700"
            >
              Add
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {profile.certifications.map((cert, index) => (
              <span
                key={index}
                className="inline-flex items-center gap-1 px-3 py-1 bg-obnc-green-50 text-obnc-green-700 rounded-full text-sm"
              >
                {cert}
                <button
                  type="button"
                  onClick={() => removeItem('certifications', index)}
                  className="hover:text-red-500"
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        </div>

        <button
          type="submit"
          className="w-full py-3 px-4 bg-obnc-green-600 text-white font-medium rounded-lg hover:bg-obnc-green-700 transition-colors"
        >
          Save Profile
        </button>
      </form>
    </div>
  );
}</content>