import React, { useState } from 'react';
import { Phone, Lock } from 'lucide-react';
import { signUpWithPhone, verifyOTP } from '../../lib/auth';
import { toast } from 'react-hot-toast';

export function PhoneAuth() {
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [loading, setLoading] = useState(false);

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await signUpWithPhone(phone);
      toast.success('OTP sent to your phone');
      setStep('otp');
    } catch (error) {
      toast.error('Failed to send OTP');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleOTPSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await verifyOTP(phone, otp);
      toast.success('Successfully authenticated');
    } catch (error) {
      toast.error('Invalid OTP');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const formatPhoneNumber = (value: string) => {
    // Format for Saudi numbers
    const cleaned = value.replace(/\D/g, '');
    if (cleaned.startsWith('966')) {
      return cleaned;
    }
    if (cleaned.startsWith('0')) {
      return `966${cleaned.slice(1)}`;
    }
    return `966${cleaned}`;
  };

  return (
    <div className="max-w-md mx-auto bg-white p-8 rounded-lg shadow-md">
      {step === 'phone' ? (
        <form onSubmit={handlePhoneSubmit} className="space-y-6">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900">Phone Authentication</h2>
            <p className="mt-2 text-sm text-gray-600">
              Enter your phone number to receive an OTP
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Phone Number
            </label>
            <div className="mt-1 relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(formatPhoneNumber(e.target.value))}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
                placeholder="966501234567"
                required
              />
            </div>
            <p className="mt-1 text-xs text-gray-500">
              Format: 966501234567 (Saudi Arabia)
            </p>
          </div>

          <button
            type="submit"
            disabled={loading}
            className={`w-full py-2 px-4 rounded-lg text-white font-medium
              ${loading
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-obnc-green-600 hover:bg-obnc-green-700'
              } transition-colors`}
          >
            {loading ? 'Sending...' : 'Send OTP'}
          </button>
        </form>
      ) : (
        <form onSubmit={handleOTPSubmit} className="space-y-6">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900">Verify OTP</h2>
            <p className="mt-2 text-sm text-gray-600">
              Enter the code sent to {phone}
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              OTP Code
            </label>
            <div className="mt-1 relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
                placeholder="Enter 6-digit code"
                maxLength={6}
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className={`w-full py-2 px-4 rounded-lg text-white font-medium
              ${loading
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-obnc-green-600 hover:bg-obnc-green-700'
              } transition-colors`}
          >
            {loading ? 'Verifying...' : 'Verify OTP'}
          </button>

          <button
            type="button"
            onClick={() => setStep('phone')}
            className="w-full text-sm text-gray-600 hover:text-gray-900"
          >
            Change phone number
          </button>
        </form>
      )}
    </div>
  );
}