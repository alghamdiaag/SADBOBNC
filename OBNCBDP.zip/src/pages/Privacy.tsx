import React from 'react';
import { Shield, Lock, FileText, UserCog, Trash2, RefreshCw } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export function Privacy() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl shadow-sm p-8">
          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Privacy Policy</h1>
            <p className="text-gray-600">
              Our commitment to protecting your personal data in accordance with Saudi Arabia's Personal Data Protection Law
            </p>
          </div>

          <div className="space-y-12">
            {/* Data Collection Section */}
            <section>
              <div className="flex items-center gap-3 mb-4">
                <Shield className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-semibold text-gray-900">Data Collection and Usage</h2>
              </div>
              <div className="pl-9 space-y-4 text-gray-600">
                <p>
                  We collect and process your personal data in accordance with Saudi Arabia's Personal Data Protection Law. 
                  This includes:
                </p>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Basic identification information</li>
                  <li>Contact details</li>
                  <li>Professional and business information</li>
                  <li>Service usage data</li>
                  <li>Communication records</li>
                </ul>
              </div>
            </section>

            {/* Your Rights Section */}
            <section>
              <div className="flex items-center gap-3 mb-4">
                <UserCog className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-semibold text-gray-900">Your Rights</h2>
              </div>
              <div className="pl-9 space-y-6">
                <div className="grid gap-6 md:grid-cols-2">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-medium text-gray-900 mb-2">Right to be Informed</h3>
                    <p className="text-sm text-gray-600">
                      You have the right to know how and why we collect your data, who we share it with, and how it's protected.
                    </p>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-medium text-gray-900 mb-2">Right to Access</h3>
                    <p className="text-sm text-gray-600">
                      You can request a copy of your personal data in a clear, readable format.
                    </p>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-medium text-gray-900 mb-2">Right to Correction</h3>
                    <p className="text-sm text-gray-600">
                      You can request corrections or updates to your personal data at any time.
                    </p>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-medium text-gray-900 mb-2">Right to Deletion</h3>
                    <p className="text-sm text-gray-600">
                      You can request the deletion of your data when it's no longer needed.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Data Protection Section */}
            <section>
              <div className="flex items-center gap-3 mb-4">
                <Lock className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-semibold text-gray-900">Data Protection Measures</h2>
              </div>
              <div className="pl-9 space-y-4 text-gray-600">
                <p>
                  We implement comprehensive security measures to protect your personal data:
                </p>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Encryption of sensitive data</li>
                  <li>Regular security assessments</li>
                  <li>Access controls and authentication</li>
                  <li>Staff training on data protection</li>
                  <li>Incident response procedures</li>
                </ul>
              </div>
            </section>

            {/* Compliance Section */}
            <section>
              <div className="flex items-center gap-3 mb-4">
                <FileText className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-semibold text-gray-900">Compliance Monitoring</h2>
              </div>
              <div className="pl-9 space-y-4 text-gray-600">
                <p>
                  Our compliance with the Personal Data Protection Law is regularly monitored through:
                </p>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Regular audits through the National Data Governance Platform</li>
                  <li>Internal compliance assessments</li>
                  <li>Documentation of data processing activities</li>
                  <li>Regular updates to our privacy practices</li>
                </ul>
              </div>
            </section>

            {/* Contact Section */}
            <section className="bg-blue-50 p-6 rounded-lg">
              <div className="flex items-center gap-3 mb-4">
                <RefreshCw className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-semibold text-gray-900">Exercise Your Rights</h2>
              </div>
              <div className="pl-9">
                <p className="text-gray-600 mb-4">
                  To exercise any of your rights or submit a privacy-related inquiry, please contact our Data Protection Officer:
                </p>
                <div className="bg-white p-4 rounded-lg inline-block">
                  <p className="text-sm text-gray-600">Email: privacy@obnc.sa</p>
                  <p className="text-sm text-gray-600">Phone: +966 XX XXX XXXX</p>
                  <p className="text-sm text-gray-600">Response Time: Within 30 days</p>
                </div>
              </div>
            </section>
          </div>

          <div className="mt-12 pt-8 border-t border-gray-200">
            <p className="text-sm text-gray-500 text-center">
              Last updated: {new Date().toLocaleDateString()}. This privacy policy is compliant with Saudi Arabia's Personal Data Protection Law.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}