import React from 'react';
import { ServiceProgress } from '../components/service/ServiceProgress';
import { DocumentUpload } from '../components/service/DocumentUpload';
import { ServiceChat } from '../components/service/ServiceChat';
import { useServiceExecution } from '../hooks/useServiceExecution';

export function ServiceExecution() {
  const serviceRequestId = 'mock-id'; // Replace with actual ID from route/props
  const {
    loading,
    error,
    uploadDocument,
    updateServiceStatus,
    sendMessage
  } = useServiceExecution(serviceRequestId);

  // Mock data - replace with actual data from your backend
  const mockServiceRequest = {
    timeline: {
      currentStep: 1,
      steps: [
        {
          id: '1',
          title: 'Service Request Submission',
          description: 'Initial service request and requirements gathering',
          status: 'completed',
          completedAt: '2024-03-01T12:00:00Z'
        },
        {
          id: '2',
          title: 'Document Collection',
          description: 'Upload required documents for service processing',
          status: 'in_progress',
          requiredDocuments: [
            'Business Registration',
            'Authorization Letter',
            'Official ID'
          ]
        },
        {
          id: '3',
          title: 'Service Provider Review',
          description: 'Review and verification of submitted documents',
          status: 'pending'
        },
        {
          id: '4',
          title: 'Service Execution',
          description: 'Processing and execution of requested service',
          status: 'pending'
        },
        {
          id: '5',
          title: 'Final Review & Completion',
          description: 'Final review and service completion confirmation',
          status: 'pending'
        }
      ]
    },
    documents: [],
    messages: []
  };

  const handleFileUpload = async (files: File[]) => {
    try {
      await Promise.all(files.map(uploadDocument));
    } catch (err) {
      console.error('Failed to upload files:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Progress and Documents */}
          <div className="lg:col-span-2 space-y-8">
            <ServiceProgress timeline={mockServiceRequest.timeline} />
            
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-6">
                Document Management
              </h3>
              <DocumentUpload
                onUpload={handleFileUpload}
                documents={mockServiceRequest.documents}
                onDelete={async (id) => {
                  // Implement document deletion
                }}
              />
            </div>
          </div>

          {/* Right Column - Chat */}
          <div className="lg:col-span-1">
            <ServiceChat
              messages={mockServiceRequest.messages}
              onSendMessage={sendMessage}
            />
          </div>
        </div>
      </div>
    </div>
  );
}