import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Search, SlidersHorizontal, ChevronDown, Globe, Menu } from 'lucide-react';
import { CategoryList } from './components/CategoryList';
import { ServiceCard } from './components/ServiceCard';
import { LanguageProvider } from './contexts/LanguageContext';
import { GlobalChat } from './components/chat/GlobalChat';
import { mockProviders } from './data/mockData';
import { AuthProvider } from './contexts/AuthContext';
import type { ServiceCategory, ServiceProvider } from './types';

export function App() {
  const [selectedCategory, setSelectedCategory] = React.useState<ServiceCategory | null>(null);
  const [searchQuery, setSearchQuery] = React.useState('');
  const [isFilterOpen, setIsFilterOpen] = React.useState(false);

  const filteredProviders = mockProviders.filter(provider => 
    (!selectedCategory || provider.category === selectedCategory.id) &&
    (!searchQuery || 
      provider.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      provider.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <AuthProvider>
      <LanguageProvider>
        <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
          {/* Header */}
          <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center justify-between h-16">
                {/* Logo */}
                <div className="flex items-center">
                  <img 
                    src="/logo.png" 
                    alt="OBNC" 
                    className="h-8 w-auto"
                  />
                </div>

                {/* Search Bar */}
                <div className="flex-1 max-w-2xl mx-8">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search for services..."
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-obnc-green-500 focus:border-obnc-green-500"
                    />
                  </div>
                </div>

                {/* Navigation */}
                <nav className="flex items-center gap-6">
                  <button className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900">
                    <Globe className="w-4 h-4" />
                    <span>العربية</span>
                  </button>
                  <button className="flex items-center gap-2 text-sm font-medium text-white bg-obnc-green-600 px-4 py-2 rounded-lg hover:bg-obnc-green-700 transition-colors">
                    Sign In
                  </button>
                  <button className="lg:hidden">
                    <Menu className="w-6 h-6 text-gray-600" />
                  </button>
                </nav>
              </div>
            </div>
          </header>

          {/* Main Content */}
          <Routes>
            <Route path="/" element={
              <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Hero Section */}
                <div className="text-center mb-12">
                  <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    Your Gateway to Business Services in Saudi Arabia
                  </h1>
                  <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                    Connect with verified service providers for legal, financial, and business support services
                  </p>
                </div>

                {/* Categories */}
                <div className="mb-12">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-semibold text-gray-900">Browse Services</h2>
                    <button
                      onClick={() => setIsFilterOpen(!isFilterOpen)}
                      className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900"
                    >
                      <SlidersHorizontal className="w-4 h-4" />
                      Filters
                      <ChevronDown className={`w-4 h-4 transform transition-transform ${isFilterOpen ? 'rotate-180' : ''}`} />
                    </button>
                  </div>
                  <CategoryList 
                    onSelect={(category) => setSelectedCategory(category)}
                    selectedId={selectedCategory?.id}
                  />
                </div>

                {/* Service Providers Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredProviders.map((provider) => (
                    <ServiceCard
                      key={provider.id}
                      provider={provider}
                      onClick={(provider) => {
                        // Handle provider selection
                        console.log('Selected provider:', provider);
                      }}
                    />
                  ))}
                </div>
              </main>
            } />
          </Routes>

          {/* Global Chat */}
          <GlobalChat />
        </div>
      </LanguageProvider>
    </AuthProvider>
  );
}

export default App;