import type { ServiceCategory, ServiceProvider } from '../types';

export const categories: ServiceCategory[] = [
  {
    id: 'legal',
    name: 'Legal Services',
    description: 'Legal assistance with contracts and compliance',
    icon: 'Scale'
  },
  {
    id: 'financial',
    name: 'Financial Services',
    description: 'Financial planning, accounting, auditing, and tax advisory',
    icon: 'Building2'
  },
  {
    id: 'investment',
    name: 'Ministry of Investment Registration',
    description: 'Guidance through registration and licensing processes',
    icon: 'Landmark'
  },
  {
    id: 'infrastructure',
    name: 'Infrastructure Development',
    description: 'Specialized infrastructure and construction services',
    icon: 'Construction'
  },
  {
    id: 'loans',
    name: 'Loan & Investment',
    description: 'Access to financial institutions and funding options',
    icon: 'Briefcase'
  },
  {
    id: 'delegations',
    name: 'Business Delegations',
    description: 'Arrangements for trade missions and business visits',
    icon: 'Users'
  },
  {
    id: 'engineering',
    name: 'Engineering Consulting',
    description: 'Technical and structural engineering consultancy',
    icon: 'HardHat'
  },
  {
    id: 'saso',
    name: 'SASO Certification',
    description: 'Saudi Arabian Standards Organization compliance assistance',
    icon: 'Shield'
  },
  {
    id: 'vendor',
    name: 'Vendor Registration',
    description: 'Registration with major Saudi companies',
    icon: 'Factory'
  },
  {
    id: 'meetings',
    name: 'Online Meetings',
    description: 'Virtual meeting coordination with providers',
    icon: 'Video'
  },
  {
    id: 'hospitality',
    name: 'Hotel & Transportation',
    description: 'Business travel and accommodation services',
    icon: 'Hotel'
  },
  {
    id: 'exhibitions',
    name: 'Exhibitions & Conferences',
    description: 'Event participation and logistics coordination',
    icon: 'CalendarCheck'
  },
  {
    id: 'realestate',
    name: 'Real Estate Services',
    description: 'Commercial and industrial property solutions',
    icon: 'Building'
  },
  {
    id: 'agency',
    name: 'Commercial Agency',
    description: 'Commercial agency and distribution representation',
    icon: 'UserCheck'
  },
  {
    id: 'customs',
    name: 'Customs & Logistics',
    description: 'Import/export and customs clearance support',
    icon: 'Truck'
  }
];

export const mockProviders: ServiceProvider[] = [
  {
    id: '1',
    name: 'Legal Experts Group',
    description: 'Professional legal services for businesses in Saudi Arabia',
    category: 'legal',
    image: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    reviewCount: 156,
    estimatedTimeline: '2-3 weeks',
    pricing: {
      currency: 'SAR',
      startingFrom: 5000
    }
  },
  {
    id: '2',
    name: 'Financial Advisors SA',
    description: 'Comprehensive financial and accounting services',
    category: 'financial',
    image: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    reviewCount: 203,
    estimatedTimeline: '1-2 weeks',
    pricing: {
      currency: 'SAR',
      startingFrom: 3500
    }
  }
];