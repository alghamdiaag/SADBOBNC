import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://wyzmzhkqvfrjggvhowi.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind5em16aGtxdmZyamdndmhvd2kiLCJyb2xlIjoiYW5vbiIsImlhdCI6MTczMDU2MTE4MiwiZXhwIjoyMDQ2MTM3MTgyfQ.oNVzSnqyRbaO9WA65fzrP3UrQ9X4RoqzbHmyDX3O1es';

export const supabase = createClient(supabaseUrl, supabaseKey);

// Move OpenAI calls to Edge Functions
export async function getChatCompletion(messages: any[]) {
  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ messages }),
    });

    if (!response.ok) {
      throw new Error('Failed to get chat completion');
    }

    const data = await response.json();
    return data.response;
  } catch (error) {
    console.error('Error getting chat completion:', error);
    throw error;
  }
}