import { PaymentIntent } from '../types/invoice';

const MOYASAR_API_KEY = 'pk_live_XJXLE5bgbNbykeL54ai1AQjti4iuoc9s42bsjNdr';
const MOYASAR_API_URL = 'https://api.moyasar.com/v1';

export async function createPaymentIntent(
  amount: number,
  currency: string,
  description: string,
  metadata: Record<string, string>
): Promise<PaymentIntent> {
  const response = await fetch(`${MOYASAR_API_URL}/payments`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${MOYASAR_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      amount: amount * 100, // Moyasar expects amounts in smallest currency unit
      currency,
      description,
      metadata,
      source: {
        type: 'creditcard',
        name: metadata.customer_name,
        number: metadata.card_number,
        cvc: metadata.cvc,
        month: metadata.exp_month,
        year: metadata.exp_year
      },
      callback_url: `${window.location.origin}/payment/callback`
    }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Payment failed');
  }

  return response.json();
}

export async function getPaymentStatus(paymentId: string): Promise<PaymentIntent> {
  const response = await fetch(`${MOYASAR_API_URL}/payments/${paymentId}`, {
    headers: {
      'Authorization': `Bearer ${MOYASAR_API_KEY}`,
    },
  });

  if (!response.ok) {
    throw new Error('Failed to fetch payment status');
  }

  return response.json();
}