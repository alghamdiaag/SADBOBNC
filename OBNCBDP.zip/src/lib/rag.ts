import { supabase } from './api';

export async function getContextFromRAG(query: string) {
  try {
    const { data, error } = await supabase.rpc('match_documents', {
      query_embedding: query,
      match_threshold: 0.78,
      match_count: 5
    });

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error getting context from RAG:', error);
    return [];
  }
}