import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: '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',
  dangerouslyAllowBrowser: true
});

export async function getChatResponse(message: string, context?: string) {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4-turbo-preview",
      messages: [
        {
          role: "system",
          content: `You are OBNC's AI assistant. ${context || ''}`
        },
        { role: "user", content: message }
      ],
      temperature: 0.7,
      max_tokens: 500
    });

    return completion.choices[0].message.content;
  } catch (error) {
    console.error('OpenAI chat error:', error);
    throw new Error('Failed to get AI response');
  }
}