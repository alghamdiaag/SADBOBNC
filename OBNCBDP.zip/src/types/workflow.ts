export type WorkflowStage = 
  | 'document_collection'
  | 'verification'
  | 'payment'
  | 'processing'
  | 'review'
  | 'completion';

export interface Workflow {
  id: string;
  serviceRequestId: string;
  currentStage: WorkflowStage;
  stages: WorkflowStage[];
  milestones: Milestone[];
  deadlines: Deadline[];
  assignees: string[];
  status: 'active' | 'paused' | 'completed' | 'cancelled';
  createdAt: string;
  updatedAt: string;
}

export interface Milestone {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  completedAt?: string;
  status: 'pending' | 'in_progress' | 'completed' | 'blocked';
  assigneeId: string;
  dependencies: string[];
}

export interface Deadline {
  id: string;
  title: string;
  date: string;
  priority: 'low' | 'medium' | 'high';
  notifyBefore: number; // days
  notified: boolean;
}