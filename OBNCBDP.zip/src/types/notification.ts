export type NotificationType = 
  | 'service_update'
  | 'document_required'
  | 'payment_required'
  | 'milestone_completed'
  | 'message_received'
  | 'deadline_approaching'
  | 'system_alert';

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  data?: Record<string, any>;
  read: boolean;
  createdAt: string;
}

export interface NotificationPreferences {
  userId: string;
  email: boolean;
  sms: boolean;
  push: boolean;
  types: {
    [K in NotificationType]: boolean;
  };
}