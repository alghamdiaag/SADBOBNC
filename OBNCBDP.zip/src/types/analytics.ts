export interface Analytics {
  serviceMetrics: ServiceMetrics;
  userMetrics: UserMetrics;
  financialMetrics: FinancialMetrics;
  timeframe: 'daily' | 'weekly' | 'monthly' | 'yearly';
  startDate: string;
  endDate: string;
}

export interface ServiceMetrics {
  totalRequests: number;
  completedRequests: number;
  averageCompletionTime: number;
  satisfactionScore: number;
  popularServices: Array<{
    serviceId: string;
    count: number;
    revenue: number;
  }>;
}

export interface UserMetrics {
  activeUsers: number;
  newUsers: number;
  returningUsers: number;
  churnRate: number;
  userSegments: Array<{
    segment: string;
    count: number;
    growth: number;
  }>;
}

export interface FinancialMetrics {
  totalRevenue: number;
  recurringRevenue: number;
  averageOrderValue: number;
  revenueByService: Record<string, number>;
  revenueByRegion: Record<string, number>;
}