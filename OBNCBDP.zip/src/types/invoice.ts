export interface Invoice {
  id: string;
  serviceRequestId: string;
  customerId: string;
  providerId: string;
  status: 'draft' | 'issued' | 'paid' | 'cancelled';
  items: InvoiceItem[];
  subtotal: number;
  vat: number;
  total: number;
  dueDate: string;
  paidAt?: string;
  createdAt: string;
  updatedAt: string;
  paymentId?: string;
  currency: string;
  invoiceNumber: string;
  notes?: string;
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
  serviceDetails?: string;
}

export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  description: string;
  status: 'initiated' | 'paid' | 'failed';
  source: {
    type: 'creditcard' | 'applepay' | 'stcpay';
    name?: string;
    number?: string;
    gateway_id?: string;
  };
  metadata: {
    invoice_id: string;
    customer_id: string;
  };
}