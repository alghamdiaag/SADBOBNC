export interface ServiceIntegration {
  id: string;
  provider: 'absher' | 'zatca' | 'bank' | 'shipping';
  config: IntegrationConfig;
  status: 'active' | 'inactive' | 'error';
  lastSync: string;
  error?: string;
}

export interface IntegrationConfig {
  apiKey?: string;
  apiSecret?: string;
  endpoint?: string;
  webhookUrl?: string;
  options?: Record<string, any>;
}

export interface IntegrationEvent {
  id: string;
  integrationId: string;
  type: string;
  status: 'success' | 'failed';
  data: any;
  timestamp: string;
}