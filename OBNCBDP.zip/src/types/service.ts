export type ServiceStatus = 
  | 'pending_approval'
  | 'approved'
  | 'in_progress'
  | 'review'
  | 'completed'
  | 'cancelled';

export interface ServiceRequest {
  id: string;
  customerId: string;
  providerId: string;
  serviceId: string;
  status: ServiceStatus;
  timeline: ServiceTimeline;
  documents: ServiceDocument[];
  messages: ServiceMessage[];
  createdAt: string;
  updatedAt: string;
}

export interface ServiceTimeline {
  steps: ServiceStep[];
  currentStep: number;
}

export interface ServiceStep {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'blocked';
  requiredDocuments?: string[];
  completedAt?: string;
}

export interface ServiceDocument {
  id: string;
  name: string;
  type: string;
  url: string;
  uploadedBy: string;
  uploadedAt: string;
  status: 'pending' | 'approved' | 'rejected';
  comments?: string;
}

export interface ServiceMessage {
  id: string;
  senderId: string;
  content: string;
  attachments?: ServiceDocument[];
  createdAt: string;
}